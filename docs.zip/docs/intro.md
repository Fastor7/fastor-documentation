---
sidebar_position: 0
---

# Tutorial Intro

The **Becho 24x7/Fastor AI** is for you, the vendor and merchants. It allows you to track your orders, products, billings, shipping and online payments, along with every detail of your online business. For each detail, the AI will help you for a smooth business.