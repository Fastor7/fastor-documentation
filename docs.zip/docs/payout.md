# Payout 

Payout is the settlement for all of the online transactions that take place. All the money received via FASTOR is settled to your respective bank after the applicable charges are deducted. to

Payouts are calculated at the end of the day, that is. after 12 AM. Only completed orders are considered for payouts so any order which is not marked completed is not considered in the day's payout.

The settlement period for payout is 48 hours. There are also three types of status, mainly** ongoing, pending and paid**. 

As the name suggested, the **paid** payout is where are the dues have been cleared, whereas, the **ongoing** **payout** is not considered finalised since it's ongoing on that particular day. The **pending** **payout** is the one where payout has been calculated but the money has not been deposited yet.  

