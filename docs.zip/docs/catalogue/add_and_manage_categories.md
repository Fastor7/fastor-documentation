---
sidebar_position: 3
---

# Add & Manage Categories