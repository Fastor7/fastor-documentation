# Feedback 

 It shows all the reviews and ratings your customers give for your services. Feedback helps you track improvement in the management of your brand and business. Keeping an eye on your customer's feedback helps you stay sharp and focus on improvements that will help elevate your brand's value and reach. 

It is advisable to check in on the feedback regularly to understand what improvement, and exactly where those changes should be applied. Constructive criticism is the best way to boost your sales, after focussing on the customer's comfort. 
